/**
 * Panoul „Google (SEO)" din bara laterală a editorului: titlul și descrierea
 * care apar în rezultatele Google. Fără build, cu API-urile globale wp.*.
 */
( function ( wp ) {
	var el = wp.element.createElement;
	var Panel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || ( wp.editPost && wp.editPost.PluginDocumentSettingPanel );
	var TextControl = wp.components.TextControl;
	var TextareaControl = wp.components.TextareaControl;
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;

	if ( ! Panel ) {
		return;
	}

	function ajutor( text, ideal, gol ) {
		return text.length + ' caractere, ideal ' + ideal + '. ' + ( text.length ? '' : gol );
	}

	function SeoPanel() {
		var meta = useSelect( function ( select ) {
			return select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {};
		}, [] );
		var editPost = useDispatch( 'core/editor' ).editPost;
		var titlu = meta.carpathia_seo_titlu || '';
		var descriere = meta.carpathia_seo_descriere || '';

		function schimba( cheie ) {
			return function ( valoare ) {
				var noi = Object.assign( {}, meta );
				noi[ cheie ] = valoare;
				editPost( { meta: noi } );
			};
		}

		return el(
			Panel,
			{ name: 'carpathia-seo', title: 'Google (SEO)' },
			el( TextControl, {
				label: 'Titlu în Google',
				value: titlu,
				onChange: schimba( 'carpathia_seo_titlu' ),
				help: ajutor( titlu, 'sub 60', 'Gol: se folosește titlul paginii.' ),
				__nextHasNoMarginBottom: true,
				__next40pxDefaultSize: true
			} ),
			el( TextareaControl, {
				label: 'Descriere în Google',
				value: descriere,
				onChange: schimba( 'carpathia_seo_descriere' ),
				help: ajutor( descriere, '120-160', 'Gol: se folosește rezumatul.' ),
				__nextHasNoMarginBottom: true
			} )
		);
	}

	wp.plugins.registerPlugin( 'carpathia-seo', { render: SeoPanel } );
} )( window.wp );
