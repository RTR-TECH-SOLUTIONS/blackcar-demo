<?php
/**
 * Transfer Otopeni – funcții temă.
 *
 * @package TransferOtopeni
 */

defined( 'ABSPATH' ) || exit;

require_once get_stylesheet_directory() . '/inc/seo.php';

/**
 * Asset-uri front-end.
 */
function carpathia_assets() {
	$dir = get_stylesheet_directory();

	wp_enqueue_style(
		'carpathia-style',
		get_stylesheet_uri(),
		array(),
		(string) filemtime( $dir . '/style.css' )
	);

	wp_enqueue_style(
		'carpathia-app',
		get_stylesheet_directory_uri() . '/assets/css/app.css',
		array( 'carpathia-style' ),
		(string) filemtime( $dir . '/assets/css/app.css' )
	);

	wp_enqueue_script(
		'carpathia-app',
		get_stylesheet_directory_uri() . '/assets/js/app.js',
		array(),
		(string) filemtime( $dir . '/assets/js/app.js' ),
		array( 'strategy' => 'defer' )
	);
}
add_action( 'wp_enqueue_scripts', 'carpathia_assets' );

/**
 * Stilurile temei se văd și în editor.
 */
function carpathia_setup() {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/app.css' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'carpathia_setup' );

/**
 * Fotografiile temei sunt servite ca WebP, în mai multe lățimi, ca telefonul să
 * nu descarce varianta de desktop. Variantele se generează din originalele din
 * tools/imagini-originale, cu numele {nume}-{lățime}.webp.
 *
 * @param string $name   Numele fotografiei, fără lățime și extensie.
 * @param int[]  $widths Lățimile generate, crescător.
 * @param int[]  $box    Lățimea și înălțimea pentru rezervarea spațiului în pagină.
 * @param string $alt    Text alternativ.
 * @param string $sizes  Cât de lată apare poza la fiecare lățime de ecran.
 * @param bool   $lcp    Poza principală a paginii: se cere imediat, fără lazy.
 */
function carpathia_theme_img( $name, $widths, $box, $alt, $sizes, $lcp = false ) {
	$base   = get_stylesheet_directory_uri() . '/assets/images/' . $name . '-';
	$srcset = array();

	foreach ( $widths as $w ) {
		$srcset[] = esc_url( $base . (int) $w . '.webp' ) . ' ' . (int) $w . 'w';
	}

	return sprintf(
		'<img src="%s" srcset="%s" sizes="%s" width="%d" height="%d" alt="%s"%s>',
		esc_url( $base . (int) $widths[ min( 1, count( $widths ) - 1 ) ] . '.webp' ),
		implode( ', ', $srcset ),
		esc_attr( $sizes ),
		(int) $box[0],
		(int) $box[1],
		esc_attr( $alt ),
		$lcp ? ' fetchpriority="high"' : ' loading="lazy" decoding="async"'
	);
}

/**
 * Fonturile pentru textul de deasupra paginii se cer înainte ca browserul să
 * ajungă la CSS, ca titlul să nu se redeseneze cu alt font.
 */
function carpathia_preload_fonts() {
	$fonts = get_stylesheet_directory_uri() . '/assets/fonts/';

	foreach ( array( 'newsreader-latin.woff2', 'instrumentsans-latin.woff2' ) as $file ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $fonts . $file ) );
	}
}
add_action( 'wp_head', 'carpathia_preload_fonts', 1 );

/**
 * Din <head> scoatem ce nu folosește site-ul: detectorul de emoji (un script
 * pe fiecare pagină), versiunea WordPress și linkurile pentru aplicații vechi
 * de blogging.
 */
function carpathia_head_cleanup() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
}
add_action( 'init', 'carpathia_head_cleanup' );
add_filter( 'emoji_svg_url', '__return_false' );

/**
 * Pozele încărcate din panou (tururi, articole) primesc variantele mici în
 * WebP, cam la jumătate din greutatea unui JPEG. Dacă serverul nu știe WebP,
 * WordPress rămâne singur la JPEG.
 */
function carpathia_webp_subsizes( $formats ) {
	$formats['image/jpeg'] = 'image/webp';
	return $formats;
}
add_filter( 'image_editor_output_format', 'carpathia_webp_subsizes' );

function carpathia_webp_quality( $quality, $mime_type ) {
	return 'image/webp' === $mime_type ? 75 : $quality;
}
add_filter( 'wp_editor_set_quality', 'carpathia_webp_quality', 10, 2 );

/**
 * Harta site-ului pentru Google: paginile, tururile și articolele. Fără autor
 * și fără categorii, care doar repetă articolele.
 */
function carpathia_sitemap_providers( $provider, $name ) {
	return in_array( $name, array( 'users', 'taxonomies' ), true ) ? false : $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'carpathia_sitemap_providers', 10, 2 );

/**
 * Arhivele de autor și de dată, categoriile, căutarea și paginile de atașament
 * repetă conținutul altor pagini, deci nu intră în indexul Google.
 */
function carpathia_robots( $robots ) {
	if ( is_author() || is_date() || is_category() || is_search() || is_attachment() ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'carpathia_robots' );

/**
 * Tip de conținut: Tururi.
 *
 * Editorul pornește cu structura deja pusă, ca proprietarul să completeze,
 * nu să construiască pagina de la zero.
 */
function carpathia_register_tours() {
	register_post_type(
		'tur',
		array(
			'labels'        => array(
				'name'               => 'Tururi',
				'singular_name'      => 'Tur',
				'add_new'            => 'Adaugă tur',
				'add_new_item'       => 'Adaugă un tur nou',
				'edit_item'          => 'Editează turul',
				'all_items'          => 'Toate tururile',
				'menu_name'          => 'Tururi',
				'search_items'       => 'Caută tururi',
				'not_found'          => 'Niciun tur adăugat încă.',
			),
			'public'        => true,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-location-alt',
			'menu_position' => 21,
			'has_archive'   => 'tururi',
			'rewrite'       => array( 'slug' => 'tururi', 'with_front' => false ),
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions', 'custom-fields' ),
			'template'      => array(
				array( 'core/paragraph', array( 'placeholder' => 'O frază despre tur: ce vede clientul și de ce merită.' ) ),
				array(
					'core/heading',
					array( 'level' => 2, 'content' => 'Ce vizităm' ),
				),
				array( 'core/list', array(), array(
					array( 'core/list-item', array( 'content' => 'Primul obiectiv' ) ),
					array( 'core/list-item', array( 'content' => 'Al doilea obiectiv' ) ),
				) ),
				array(
					'core/heading',
					array( 'level' => 2, 'content' => 'Ce include' ),
				),
				array( 'core/paragraph', array( 'placeholder' => 'Transport, șofer vorbitor de engleză, combustibil, parcări.' ) ),
			),
		)
	);
}
add_action( 'init', 'carpathia_register_tours' );

/**
 * Câmpurile practice ale unui tur (durată, plecare, preț, persoane).
 *
 * Meta expusă în REST ca să fie editabilă din panoul lateral al editorului.
 */
function carpathia_register_tour_meta() {
	$fields = array(
		'durata'     => 'Durată (ex: 12 ore)',
		'plecare'    => 'Plecare din (ex: București)',
		'pret'       => 'Preț de la (ex: 120 €)',
		'persoane'   => 'Persoane (ex: 1-7)',
	);

	foreach ( $fields as $key => $label ) {
		register_post_meta(
			'tur',
			'carpathia_' . $key,
			array(
				'type'         => 'string',
				'description'  => $label,
				'single'       => true,
				'show_in_rest' => true,
				'default'      => '',
				'auth_callback' => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}
}
add_action( 'init', 'carpathia_register_tour_meta' );

/**
 * Tip de conținut: Vedete. Pozele cu invitații cunoscuți ai firmei, cu numele
 * lor, afișate pe prima pagină. Nu au pagină proprie: doar poza și numele, iar
 * proprietarul le adaugă din panou ca pe orice altă intrare.
 */
function carpathia_register_vedete() {
	register_post_type(
		'vedeta',
		array(
			'labels'        => array(
				'name'          => 'Vedete',
				'singular_name' => 'Vedetă',
				'add_new'       => 'Adaugă vedetă',
				'add_new_item'  => 'Adaugă o vedetă nouă',
				'edit_item'     => 'Editează vedeta',
				'all_items'     => 'Toate vedetele',
				'menu_name'     => 'Vedete',
				'search_items'  => 'Caută vedete',
				'not_found'     => 'Nicio vedetă adăugată încă.',
			),
			'public'        => false,
			'show_ui'       => true,
			'show_in_rest'  => true,
			'menu_icon'     => 'dashicons-star-filled',
			'menu_position' => 22,
			'supports'      => array( 'title', 'thumbnail', 'excerpt', 'page-attributes' ),
		)
	);
}
add_action( 'init', 'carpathia_register_vedete' );

/**
 * Categoriile blogului funcționează ca „regiuni" pentru ghidul de destinații,
 * deci arhivele lor primesc un titlu propriu.
 */
function carpathia_archive_title( $title ) {
	if ( is_category() ) {
		$title = single_cat_title( '', false );
	} elseif ( is_post_type_archive( 'tur' ) ) {
		$title = 'Tururi';
	}
	return $title;
}
add_filter( 'get_the_archive_title', 'carpathia_archive_title' );

/**
 * Numărul de tururi afișate în arhivă.
 */
function carpathia_tour_archive_query( $query ) {
	if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'tur' ) ) {
		$query->set( 'posts_per_page', 12 );
		$query->set( 'orderby', 'menu_order date' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'carpathia_tour_archive_query' );

/**
 * Articolul de blog pornește cu structura gata pusă: o frază, un rând de poze,
 * încă o frază. Proprietarul adaugă poze din telefon și scrie între ele, fără
 * să construiască pagina de la zero.
 */
function carpathia_post_template() {
	$post = get_post_type_object( 'post' );

	if ( ! $post ) {
		return;
	}

	$post->template = array(
		array( 'core/paragraph', array( 'placeholder' => 'Unde ați fost, cu cine și cum a fost drumul.' ) ),
		array( 'core/gallery', array( 'columns' => 3, 'linkTo' => 'none', 'sizeSlug' => 'large' ) ),
		array( 'core/paragraph', array( 'placeholder' => 'Unde ați oprit, ce a plăcut oamenilor, cât a ținut ziua.' ) ),
	);
}
add_action( 'init', 'carpathia_post_template', 11 );

/**
 * Câmpul de titlu spune ce fel de titlu se așteaptă.
 */
function carpathia_title_placeholder( $text, $post ) {
	if ( $post && 'post' === $post->post_type ) {
		return 'Titlu, de exemplu: O zi la Bran, cu o familie din Franța';
	}
	return $text;
}
add_filter( 'enter_title_here', 'carpathia_title_placeholder', 10, 2 );

/**
 * Imaginea reprezentativă e cea care apare în lista de articole. Dacă a fost
 * uitată, o luăm pe prima din articol, ca articolul să nu iasă fără poză.
 */
function carpathia_auto_thumbnail( $post_id, $post ) {
	if ( 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || has_post_thumbnail( $post_id ) ) {
		return;
	}

	if ( preg_match( '/wp-image-(\d+)/', $post->post_content, $m )
		|| preg_match( '/"id":(\d+)/', $post->post_content, $m ) ) {
		$imagine = (int) $m[1];

		if ( wp_attachment_is_image( $imagine ) ) {
			set_post_thumbnail( $post_id, $imagine );
		}
	}
}
add_action( 'save_post', 'carpathia_auto_thumbnail', 10, 2 );

/**
 * Semnul de brand: logo-ul firmei, alb pe fundal transparent, cu numele
 * firmei ca text alternativ.
 */
function carpathia_brand( $context = 'header' ) {
	$clasa = 'brand' . ( 'footer' === $context ? ' brand--footer' : '' );
	// WebP fără pierderi: aceeași imagine ca PNG-ul, de aproape trei ori mai ușoară.
	$file  = '/assets/images/logo-transfer-otopeni.webp';
	// Versiunea din adresă forțează browserul să ia logoul nou după o schimbare.
	$logo  = get_stylesheet_directory_uri() . $file . '?v=' . filemtime( get_stylesheet_directory() . $file );

	return sprintf(
		'<a class="%s" href="%s"><img class="brand__logo" src="%s" width="1165" height="108" alt="%s" decoding="async"%s></a>',
		esc_attr( $clasa ),
		esc_url( home_url( '/' ) ),
		esc_url( $logo ),
		esc_attr( get_bloginfo( 'name' ) ),
		'footer' === $context ? ' loading="lazy"' : ''
	);
}

/**
 * Datele de contact stau într-un singur loc, ca să nu fie hardcodate prin șabloane.
 */
function carpathia_contact( $key = null ) {
	// Datele de contact stau intr-un singur loc, ca sa se schimbe dintr-un
	// singur fisier daca firma isi schimba numarul sau adresa de e-mail.
	$data = array(
		'telefon'         => '+40 726 260 471',
		'telefon_link'    => '+40726260471',
		'telefon_2'       => '+40 746 464 826',
		'telefon_2_link'  => '+40746464826',
		'whatsapp'        => '40726260471',
		'email'           => 'contact@transferotopeni.ro',
		'email_2'         => 'trip2trip@transferotopeni.ro',
		'program'         => '24h din 24h, 7 zile din 7',
		'adresa'          => 'București',
		'facebook'        => 'https://www.facebook.com/profile.php?id=100063703564985',
	);

	// Linkul de WhatsApp se compune aici, nu prin carpathia_whatsapp_link(),
	// pentru ca aceea cheama inapoi carpathia_contact() si ar intra in bucla.
	$data['whatsapp_link'] = 'https://wa.me/' . $data['whatsapp'] . '?text=' . rawurlencode( 'Bună ziua! Aș dori o ofertă pentru un transfer.' );

	if ( null === $key ) {
		return $data;
	}
	return $data[ $key ] ?? '';
}

/**
 * Shortcode-uri simple pentru datele de contact, folosite în șabloane și pattern-uri.
 */
function carpathia_contact_shortcode( $atts ) {
	$atts   = shortcode_atts( array( 'camp' => 'telefon' ), $atts );
	$valoare = carpathia_contact( $atts['camp'] );
	return 'whatsapp_link' === $atts['camp'] ? esc_url( $valoare ) : esc_html( $valoare );
}
add_shortcode( 'contact', 'carpathia_contact_shortcode' );

/**
 * Link-ul de WhatsApp cu mesaj pre-completat, refolosit peste tot.
 */
function carpathia_whatsapp_link( $mesaj = '' ) {
	$mesaj = $mesaj ? $mesaj : 'Bună ziua! Aș dori o ofertă pentru un transfer.';
	return 'https://wa.me/' . carpathia_contact( 'whatsapp' ) . '?text=' . rawurlencode( $mesaj );
}

/**
 * Butonul flotant de WhatsApp, standard în nișă.
 */
function carpathia_whatsapp_button() {
	if ( is_admin() ) {
		return;
	}
	printf(
		'<a class="wa-float" href="%s" target="_blank" rel="noopener" aria-label="Scrie-ne pe WhatsApp">
			<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.47 14.38c-.3-.15-1.74-.86-2-.96-.27-.1-.47-.15-.66.15-.2.29-.76.95-.93 1.15-.17.2-.34.22-.63.07-.3-.15-1.24-.46-2.36-1.46-.87-.78-1.46-1.73-1.63-2.03-.17-.3-.02-.45.13-.6.13-.13.3-.34.44-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.66-1.6-.9-2.19-.24-.57-.48-.5-.66-.5h-.57c-.2 0-.51.07-.78.37-.27.29-1.02 1-1.02 2.44 0 1.43 1.05 2.82 1.2 3.02.14.2 2.05 3.13 4.97 4.39.69.3 1.24.48 1.66.61.7.22 1.33.19 1.84.12.56-.09 1.74-.71 1.98-1.4.25-.69.25-1.28.17-1.4-.07-.13-.27-.2-.56-.35M12.05 21.8h-.02a9.8 9.8 0 0 1-4.99-1.37l-.36-.21-3.71.97 1-3.62-.24-.37a9.79 9.79 0 0 1-1.5-5.23c0-5.41 4.4-9.81 9.82-9.81 2.62 0 5.09 1.02 6.94 2.88a9.75 9.75 0 0 1 2.87 6.94c0 5.41-4.4 9.82-9.81 9.82M20.52 3.45A11.7 11.7 0 0 0 12.05 0C5.6 0 .35 5.25.35 11.7c0 2.06.54 4.08 1.56 5.86L.25 24l6.59-1.73a11.68 11.68 0 0 0 5.21 1.25h.01c6.45 0 11.7-5.25 11.7-11.7 0-3.13-1.22-6.07-3.43-8.28"/></svg>
			<span class="wa-float__label">Scrie pe WhatsApp</span>
		</a>',
		esc_url( carpathia_whatsapp_link() )
	);
}
add_action( 'wp_footer', 'carpathia_whatsapp_button' );

/**
 * Filtrele ghidului: „Toate" plus categoriile care chiar au articole.
 *
 * Shortcode, nu pattern, pentru că pattern-urile temei se încarcă pe `init`,
 * înainte ca `is_category()` să fie de încredere. Shortcode-urile din șabloane
 * sunt rezolvate la randare (vezi `get_the_block_template_html()`).
 */
function carpathia_guide_filters() {
	$cats = get_categories(
		array(
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
		)
	);

	if ( ! $cats ) {
		return '';
	}

	$blog = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
	$curent = is_category() ? get_queried_object_id() : 0;

	$out = '<ul class="guide-filters">';
	$out .= sprintf(
		'<li class="%s"><a href="%s">Toate articolele</a></li>',
		$curent ? '' : 'is-active',
		esc_url( $blog )
	);

	foreach ( $cats as $cat ) {
		$out .= sprintf(
			'<li class="%s"><a href="%s">%s</a></li>',
			(int) $cat->term_id === (int) $curent ? 'is-active' : '',
			esc_url( get_category_link( $cat ) ),
			esc_html( $cat->name )
		);
	}

	return $out . '</ul>';
}
add_shortcode( 'ghid_filtre', 'carpathia_guide_filters' );

/**
 * Articole înrudite la finalul unui ghid: întâi din aceeași categorie, apoi
 * completate cu cele mai recente, ca secțiunea să fie mereu plină.
 */
function carpathia_related_posts() {
	$id = get_queried_object_id();

	if ( ! $id || 'post' !== get_post_type( $id ) ) {
		return '';
	}

	$cats  = wp_get_post_terms( $id, 'category', array( 'fields' => 'ids' ) );
	$baza  = array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'post__not_in'        => array( $id ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	$posts = array();

	if ( $cats ) {
		$posts = get_posts( $baza + array( 'category__in' => $cats ) );
	}

	if ( count( $posts ) < 3 ) {
		$exclus    = array_merge( array( $id ), wp_list_pluck( $posts, 'ID' ) );
		$completare = get_posts(
			array_merge(
				$baza,
				array(
					'posts_per_page' => 3 - count( $posts ),
					'post__not_in'   => $exclus,
				)
			)
		);
		$posts = array_merge( $posts, $completare );
	}

	if ( ! $posts ) {
		return '';
	}

	$out = '<ul class="related-grid">';

	foreach ( $posts as $p ) {
		$link = get_permalink( $p );
		$cat  = get_the_category( $p->ID );
		$out .= '<li>';

		if ( has_post_thumbnail( $p ) ) {
			$out .= sprintf(
				'<a class="guide-thumb" href="%s" tabindex="-1" aria-hidden="true">%s</a>',
				esc_url( $link ),
				get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) )
			);
		}

		if ( $cat ) {
			$out .= '<p class="guide-cat">' . esc_html( $cat[0]->name ) . '</p>';
		}

		$out .= sprintf(
			'<h3 class="guide-title"><a href="%s">%s</a></h3>',
			esc_url( $link ),
			esc_html( get_the_title( $p ) )
		);
		$out .= '<p class="guide-excerpt">' . esc_html( wp_trim_words( get_the_excerpt( $p ), 24 ) ) . '</p>';
		$out .= '</li>';
	}

	return $out . '</ul>';
}
add_shortcode( 'articole_similare', 'carpathia_related_posts' );

/**
 * Categorii de blocuri proprii, ca pattern-urile temei să fie ușor de găsit.
 */
function carpathia_pattern_categories() {
	register_block_pattern_category(
		'carpathia',
		array( 'label' => 'Transfer Otopeni' )
	);
}
add_action( 'init', 'carpathia_pattern_categories' );
