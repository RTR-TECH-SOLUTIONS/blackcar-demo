<?php
/**
 * Title: Acasă – hero cu bandă de cerere ofertă
 * Slug: carpathia/home-hero
 * Categories: carpathia
 * Inserter: no
 */
$wa  = carpathia_contact( 'whatsapp' );
?>
<!-- wp:group {"align":"full","className":"hero","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"4.5rem","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull hero" style="padding-top:4.5rem;padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:html -->
	<div class="hero__media">
		<?php echo carpathia_theme_img( 'hero-terminal', array( 640, 960, 1280, 1600, 2200 ), array( 2200, 1232 ), '', '100vw', true ); ?>
	</div>
	<!-- /wp:html -->

	<!-- wp:group {"align":"wide","className":"hero__content","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide hero__content">

		<!-- wp:group {"className":"hero__panel","layout":{"type":"default"}} -->
		<div class="wp-block-group hero__panel">

		<!-- wp:html -->
		<p class="hero__eyebrow"><?php echo esc_html( carpathia_contact( 'program' ) ); ?></p>
		<!-- /wp:html -->

		<!-- wp:heading {"level":1,"className":"hero__title"} -->
		<h1 class="wp-block-heading hero__title">Transferuri aeroport și tururi private din București</h1>
		<!-- /wp:heading -->

		<!-- wp:html -->
		<div class="hero__aside">
			<p class="hero__lead">Urmărim numărul zborului și ajustăm ora preluării în funcție de aterizare.</p>
			<ul class="hero__points">
				<li>Timp de așteptare inclus în preț: 60 de minute de la ora aterizării sau de la ora stabilită cu dumneavoastră</li>
				<li>Este de preferat să aveți WhatsApp pe numărul de contact, ca să ținem legătura mai ușor</li>
			</ul>
		</div>
		<!-- /wp:html -->

		<!-- wp:group {"className":"hero__cta","layout":{"type":"default"}} -->
		<div class="wp-block-group hero__cta">

			<!-- wp:buttons {"className":"hero__actions","style":{"spacing":{"blockGap":"0.75rem"}}} -->
			<div class="wp-block-buttons hero__actions">
				<!-- wp:button {"className":"is-style-outline hero__phone"} -->
				<div class="wp-block-button is-style-outline hero__phone"><a class="wp-block-button__link wp-element-button" href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon' ) ); ?></a></div>
				<!-- /wp:button -->

				<!-- wp:button {"className":"is-style-outline hero__phone"} -->
				<div class="wp-block-button is-style-outline hero__phone"><a class="wp-block-button__link wp-element-button" href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_2_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon_2' ) ); ?></a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:group -->

		</div>
		<!-- /wp:group -->

	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"quote-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull quote-band" id="cerere">

	<!-- wp:html -->
	<div class="quote-band__inner">
		<div class="quote-band__head">
			<p class="quote-band__title">Detalii despre cursă</p>
		</div>

		<form class="quote-form quote-form--band" data-quote-form data-whatsapp="<?php echo esc_attr( $wa ); ?>" data-email="<?php echo esc_attr( carpathia_contact( 'email' ) ); ?>">
			<div class="quote-field">
				<label for="q-from">Locul de preluare</label>
				<input type="text" id="q-from" name="preluare" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-to">Locul de destinație</label>
				<input type="text" id="q-to" name="destinatie" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-date">Data</label>
				<input type="date" id="q-date" name="data">
			</div>

			<div class="quote-field">
				<label for="q-time">Ora</label>
				<input type="time" id="q-time" name="ora">
			</div>

			<div class="quote-field">
				<label for="q-flight">Numărul de zbor</label>
				<input type="text" id="q-flight" name="zbor" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-pax">Numărul de persoane</label>
				<select id="q-pax" name="persoane">
					<option value=""></option>
					<option>1</option><option>2</option><option>3</option>
					<option>4</option><option>5</option><option>6</option>
					<option>7</option>
				</select>
			</div>

			<div class="quote-field">
				<label for="q-tel">Telefon de contact WhatsApp</label>
				<input type="tel" id="q-tel" name="telefon" autocomplete="tel">
			</div>

			<button type="submit" class="quote-form__submit">Trimite detaliile cursei</button>
		</form>

		<p class="quote-form__fallback" data-quote-fallback hidden>
			S-a deschis WhatsApp cu mesajul completat. Dacă nu s-a deschis,
			<a href="#" data-quote-mailto>trimiteți aceleași date pe e-mail</a>.
		</p>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
