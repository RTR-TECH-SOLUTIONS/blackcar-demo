<?php
/**
 * Title: Acasă – hero cu bandă de cerere ofertă
 * Slug: carpathia/home-hero
 * Categories: carpathia
 * Inserter: no
 */
$img = get_stylesheet_directory_uri() . '/assets/images/hero-blackcar.jpg';
$wa  = carpathia_contact( 'whatsapp' );
?>
<!-- wp:group {"align":"full","className":"hero","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull hero" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:html -->
	<div class="hero__media">
		<img src="<?php echo esc_url( $img ); ?>" width="1800" height="2400" alt="" fetchpriority="high" decoding="async">
	</div>
	<!-- /wp:html -->

	<!-- wp:group {"align":"wide","className":"hero__content","layout":{"type":"default"}} -->
	<div class="wp-block-group alignwide hero__content">

		<!-- wp:paragraph {"className":"hero__eyebrow"} -->
		<p class="hero__eyebrow">Transferuri și tururi private din București</p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1,"style":{"spacing":{"margin":{"bottom":"1.1rem"}}}} -->
		<h1 class="wp-block-heading" style="margin-bottom:1.1rem">Vă așteptăm la terminal, cu numele pe plăcuță</h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"className":"hero__lead"} -->
		<p class="hero__lead">Urmărim numărul zborului și mutăm ora preluării dacă aterizați mai târziu. Prețul se confirmă înainte de cursă și rămâne același, indiferent de trafic sau de ora din noapte.</p>
		<!-- /wp:paragraph -->

		<!-- wp:html -->
		<ul class="hero__points">
			<li>Șaizeci de minute de așteptare incluse la sosiri</li>
			<li>Preț fix, confirmat în scris pe WhatsApp</li>
			<li>Șoferi proprii, vorbitori de engleză</li>
		</ul>
		<!-- /wp:html -->

		<!-- wp:buttons {"className":"hero__actions","style":{"spacing":{"blockGap":"0.75rem","margin":{"top":"2rem"}}}} -->
		<div class="wp-block-buttons hero__actions" style="margin-top:2rem">
			<!-- wp:button -->
			<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#cerere">Cere prețul pentru cursa ta</a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-outline"} -->
			<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_link' ) ); ?>">Sună <?php echo esc_html( carpathia_contact( 'telefon' ) ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"quote-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull quote-band" id="cerere">

	<!-- wp:html -->
	<div class="quote-band__inner">
		<div class="quote-band__head">
			<p class="quote-band__title">Fișa cursei</p>
			<p class="quote-band__note">Completați ruta și numărul zborului. Vă răspundem pe WhatsApp cu prețul stabilit înainte de cursă, fără alte taxe adăugate.</p>
		</div>

		<form class="quote-form quote-form--band" data-quote-form data-whatsapp="<?php echo esc_attr( $wa ); ?>" data-email="<?php echo esc_attr( carpathia_contact( 'email' ) ); ?>">
			<div class="quote-field">
				<label for="q-from">Preluare din</label>
				<input type="text" id="q-from" name="preluare" value="Aeroport Otopeni" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-to">Destinație</label>
				<input type="text" id="q-to" name="destinatie" placeholder="Hotel sau adresă" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-date">Data</label>
				<input type="date" id="q-date" name="data">
			</div>

			<div class="quote-field">
				<label for="q-time">Ora</label>
				<input type="time" id="q-time" name="ora" value="09:00">
			</div>

			<div class="quote-field">
				<label for="q-flight">Număr zbor</label>
				<input type="text" id="q-flight" name="zbor" placeholder="RO 392" autocomplete="off">
			</div>

			<div class="quote-field">
				<label for="q-pax">Persoane</label>
				<select id="q-pax" name="persoane">
					<option>1</option><option>2</option><option>3</option>
					<option>4</option><option>5</option><option>6</option>
				</select>
			</div>

			<div class="quote-field">
				<label for="q-tel">Telefon de contact</label>
				<input type="tel" id="q-tel" name="telefon" placeholder="07xx xxx xxx" autocomplete="tel">
			</div>

			<button type="submit" class="quote-form__submit">Cere prețul pentru cursa ta</button>
		</form>

		<p class="quote-form__fallback" data-quote-fallback hidden>
			S-a deschis WhatsApp cu mesajul completat. Dacă nu s-a deschis,
			<a href="#" data-quote-mailto>trimiteți aceleași date pe e-mail</a>.
		</p>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
