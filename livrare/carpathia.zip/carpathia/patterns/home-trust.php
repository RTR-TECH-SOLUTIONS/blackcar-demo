<?php
/**
 * Title: Acasă – bandă de încredere
 * Slug: carpathia/home-trust
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"trust-strip","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-group alignfull trust-strip" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:html -->
	<div class="trust-strip__grid alignwide">
		<div class="trust-item">
			<p class="trust-item__label">60 de minute</p>
			<p class="trust-item__text">Așteptare inclusă la sosiri, din momentul aterizării</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">Preț stabilit înainte</p>
			<p class="trust-item__text">Vi-l spunem în scris înainte de cursă și nu se mai schimbă</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">Fără alte taxe</p>
			<p class="trust-item__text">Nimic adăugat pentru bagaje, noapte, trafic sau parcare</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">Urmărim zborul</p>
			<p class="trust-item__text">Venim la ora la care aterizați efectiv, nu la ora din bilet</p>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
