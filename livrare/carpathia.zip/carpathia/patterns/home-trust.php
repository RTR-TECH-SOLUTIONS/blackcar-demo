<?php
/**
 * Title: Acasă – bandă de încredere
 * Slug: carpathia/home-trust
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"trust-strip","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-group alignfull trust-strip" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:html -->
	<div class="trust-strip__grid alignwide">
		<div class="trust-item">
			<p class="trust-item__label">60 de minute</p>
			<p class="trust-item__text">Așteptare inclusă la sosiri, din momentul aterizării</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">Preț fix</p>
			<p class="trust-item__text">Confirmat în scris înainte de cursă, fără taxe adăugate</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">Non-stop</p>
			<p class="trust-item__text">Curse la 3 dimineața, la fel ca la prânz</p>
		</div>
		<div class="trust-item">
			<p class="trust-item__label">15+ ani</p>
			<p class="trust-item__text">De când ducem oameni la și de la aeroport</p>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
