<?php
/**
 * Title: Acasă – servicii
 * Slug: carpathia/home-services
 * Categories: carpathia
 * Inserter: no
 */
$u = get_stylesheet_directory_uri() . '/assets/images/';
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Ce facem</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Trei tipuri de curse, aceleași mașini și aceiași șoferi. Nu subcontractăm.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="cards cards--3 alignwide">

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'serviciu-aeroport.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Avioane pe pista aeroportului la apus">
			</div>
			<div class="card__body">
				<h3 class="card__title"><a href="/transfer-aeroport/">Transfer aeroport</a></h3>
				<p class="card__text">Otopeni și Băneasa, la sosire și la plecare. Urmărim zborul și ajustăm ora dacă întârzie. La sosiri vă așteptăm în zona de ieșire, cu plăcuță.</p>
				<div class="card__meta"><span><strong>De la 130 lei</strong> spre București</span></div>
			</div>
		</article>

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'serviciu-corporate.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Bancheta din spate a vanului Blackcar, tapițerie din piele">
			</div>
			<div class="card__body">
				<h3 class="card__title"><a href="/firme/">Curse pentru firme</a></h3>
				<p class="card__text">Delegații, parteneri veniți din străinătate, transport între sedii. Aceleași mașini rezervate lunar, o singură factură la sfârșit de lună.</p>
				<div class="card__meta"><span><strong>Contract lunar</strong> sau cursă separată</span></div>
			</div>
		</article>

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'serviciu-tururi.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Muntele Tâmpa cu inscripția Brașov, deasupra orașului">
			</div>
			<div class="card__body">
				<h3 class="card__title"><a href="/tururi/">Tururi private</a></h3>
				<p class="card__text">O zi la Bran și Peleș, Transfăgărășanul vara, un weekend prin Bucovina. Mergeți doar cu grupul dumneavoastră, cu opriri unde cereți.</p>
				<div class="card__meta"><span><strong>1-7 persoane</strong> pe tur</span></div>
			</div>
		</article>

	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
