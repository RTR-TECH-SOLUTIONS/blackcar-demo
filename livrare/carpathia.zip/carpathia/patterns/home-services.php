<?php
/**
 * Title: Acasă – servicii
 * Slug: carpathia/home-services
 * Categories: carpathia
 * Inserter: no
 */
$u = get_stylesheet_directory_uri() . '/assets/images/';
?>
<!-- wp:group {"align":"full","anchor":"transferuri","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" id="transferuri" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Ce facem</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Două tipuri de curse, aceleași mașini și aceiași șoferi. Nu subcontractăm.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="cards cards--2 alignwide">

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'serviciu-aeroport.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Avioane pe pista aeroportului la apus">
			</div>
			<div class="card__body">
				<h3 class="card__title"><a href="#cerere">Transfer aeroport</a></h3>
				<p class="card__text">De la și către Henri Coandă și Băneasa. Ne spuneți numărul zborului, îl urmărim și venim la ora la care aterizați efectiv. La sosiri vă așteptăm în zona de ieșire, cu plăcuță.</p>
				<div class="card__meta"><span><strong>Henri Coandă și Băneasa</strong>, la sosire și la plecare</span></div>
			</div>
		</article>

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'serviciu-tururi.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Muntele Tâmpa cu inscripția Brașov, deasupra orașului">
			</div>
			<div class="card__body">
				<h3 class="card__title"><a href="#tururi">Tururi private</a></h3>
				<p class="card__text">Pe trasee recomandate de noi sau pe unde doriți dumneavoastră. Excursii de o zi, cu plecare dimineața de la hotel și întoarcere seara.</p>
				<div class="card__meta"><span><strong>Excursii de o zi</strong>, cu grupul dumneavoastră</span></div>
			</div>
		</article>

	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
