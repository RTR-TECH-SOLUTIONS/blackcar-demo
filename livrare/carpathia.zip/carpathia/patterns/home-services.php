<?php
/**
 * Title: Acasă – servicii
 * Slug: carpathia/home-services
 * Categories: carpathia
 * Inserter: no
 */
$u = get_stylesheet_directory_uri() . '/assets/images/';
?>
<!-- wp:group {"align":"full","anchor":"transferuri","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" id="transferuri" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:html -->
	<div class="cards cards--2 alignwide">

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'auto-vclass-aeroport.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Vanul Mercedes-Benz V-Class în parcarea aeroportului, cu un avion pe pistă în spate">
			</div>
			<div class="card__body">
				<h2 class="card__title"><a href="#cerere">Transferuri aeroport</a></h2>
				<p class="card__text">De la și către aeroportul Henri Coandă - Otopeni și Aurel Vlaicu - Băneasa. Ne spuneți numărul zborului, îl urmărim și venim la ora la care aterizați efectiv sau la ora dorită, cu timpul de întârziere stabilit de dumneavoastră.</p>
			</div>
		</article>

		<article class="card">
			<div class="card__media">
				<img src="<?php echo esc_url( $u . 'tururi-patru-obiective.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Castelul Peleș, Castelul Bran, barajul Paltinu și salina Slănic Prahova">
			</div>
			<div class="card__body">
				<h2 class="card__title"><a href="#tururi">Tururi private</a></h2>
				<p class="card__text">Pe trasee recomandate de noi sau oriunde doriți dumneavoastră.</p>
			</div>
		</article>

	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
