<?php
/**
 * Title: Acasă – vedete
 * Slug: carpathia/home-vedete
 * Categories: carpathia
 * Inserter: no
 *
 * Lista se construiește aici, nu cu blocul de listare al WordPress-ului: acela
 * cere un tip de conținut cu pagini publice, iar vedetele n-au pagină proprie,
 * doar poza și numele.
 */
$vedete = get_posts(
	array(
		'post_type'      => 'vedeta',
		'post_status'    => 'publish',
		'posts_per_page' => 8,
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
	)
);
?>
<!-- wp:group {"align":"full","anchor":"vedete","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignfull" id="vedete" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Din vedetele noastre</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Oameni cunoscuți care au mers cu noi, la festivaluri și la aeroport.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<ul class="vedete-grid alignwide">
		<?php foreach ( $vedete as $vedeta ) : ?>
		<li class="vedeta">
			<?php echo get_the_post_thumbnail( $vedeta, 'medium_large', array( 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
		</li>
		<?php endforeach; ?>
	</ul>
	<!-- /wp:html -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"left"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:button {"className":"is-style-outline"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/blog/">Impresii din drumeții</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
