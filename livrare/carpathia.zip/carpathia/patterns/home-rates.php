<?php
/**
 * Title: Acasă – prețuri pe rute
 * Slug: carpathia/home-rates
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"cta-band","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull cta-band" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Cât costă de la Otopeni</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Prețurile de mai jos includ TVA, combustibilul, parcarea la aeroport și așteptarea. Nu se schimbă noaptea și nici în trafic.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="rates alignwide">
		<div class="rates__scroll">
			<table>
				<caption>Tarife orientative pentru plecarea din Aeroportul Henri Coandă. Pentru alte rute, trimiteți adresa și primiți prețul exact.</caption>
				<thead>
					<tr>
						<th scope="col">Destinație</th>
						<th scope="col">Sedan, 1-3 persoane</th>
						<th scope="col">Van, 4-7 persoane</th>
					</tr>
				</thead>
				<tbody>
					<tr><th scope="row">București, zona centrală</th><td class="price">130 lei</td><td class="price">180 lei</td></tr>
					<tr><th scope="row">București, restul sectoarelor</th><td class="price">140-170 lei</td><td class="price">190-220 lei</td></tr>
					<tr><th scope="row">Ploiești</th><td class="price">280 lei</td><td class="price">360 lei</td></tr>
					<tr><th scope="row">Sinaia</th><td class="price">450 lei</td><td class="price">570 lei</td></tr>
					<tr><th scope="row">Brașov</th><td class="price">550 lei</td><td class="price">690 lei</td></tr>
					<tr><th scope="row">Constanța</th><td class="price">780 lei</td><td class="price">950 lei</td></tr>
					<tr><th scope="row">Alte localități</th><td class="price">3,5 lei/km</td><td class="price">4,5 lei/km</td></tr>
				</tbody>
			</table>
		</div>
	</div>
	<!-- /wp:html -->

	<!-- wp:html -->
	<div class="estimator alignwide" data-estimator>
		<p class="estimator__title">Calculați rapid</p>
		<div class="estimator__row">
			<label class="estimator__field">
				<span>De la Otopeni către</span>
				<select data-estimator-ruta>
					<option data-sedan="130 lei" data-van="180 lei">București, zona centrală</option>
					<option data-sedan="140-170 lei" data-van="190-220 lei">București, restul sectoarelor</option>
					<option data-sedan="280 lei" data-van="360 lei">Ploiești</option>
					<option data-sedan="450 lei" data-van="570 lei">Sinaia</option>
					<option data-sedan="550 lei" data-van="690 lei">Brașov</option>
					<option data-sedan="780 lei" data-van="950 lei">Constanța</option>
					<option data-sedan="3,5 lei/km" data-van="4,5 lei/km">Altă localitate</option>
				</select>
			</label>

			<label class="estimator__field">
				<span>Mașină</span>
				<select data-estimator-masina>
					<option value="sedan">Sedan, 1-3 persoane</option>
					<option value="van">Van, 4-7 persoane</option>
				</select>
			</label>

			<p class="estimator__out">
				<span>Preț</span>
				<strong data-estimator-rezultat></strong>
			</p>
		</div>
		<p class="estimator__note">Preț orientativ, fix pentru rutele din listă. Pentru adresa exactă vă confirmăm suma în scris înainte de cursă.</p>
	</div>
	<!-- /wp:html -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"left"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--30)">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#cerere">Cere prețul pentru cursa ta</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
