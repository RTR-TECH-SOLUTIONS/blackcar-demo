<?php
/**
 * Title: Acasă – recenzii
 * Slug: carpathia/home-reviews
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"section-dark","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull section-dark" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Ce spun oamenii pe care i-am dus</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Recenzii publice de pe Google, lăsate de clienți reali.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="reviews alignwide">
		<figure class="review">
			<p class="review__stars" aria-label="Cinci stele din cinci">★★★★★</p>
			<blockquote class="review__text">„Avionul a întârziat două ore la Otopeni și tot ne aștepta cineva la ieșire, fără să ne coste în plus. Rar așa ceva."</blockquote>
			<figcaption class="review__who"><strong>Andrei M.</strong> Transfer Otopeni – Piața Victoriei</figcaption>
		</figure>
		<figure class="review">
			<p class="review__stars" aria-label="Cinci stele din cinci">★★★★★</p>
			<blockquote class="review__text">„Am dus doi parteneri din Germania la Brașov. Șoferul vorbea engleză bine și a știut să răspundă la întrebări despre oraș tot drumul."</blockquote>
			<figcaption class="review__who"><strong>Cristina D.</strong> Cursă pentru firmă, București – Brașov</figcaption>
		</figure>
		<figure class="review">
			<p class="review__stars" aria-label="Cinci stele din cinci">★★★★★</p>
			<blockquote class="review__text">„Tur la Bran și Peleș cu părinții mei, care merg greu. A oprit exact unde am cerut și ne-a așteptat fără grabă la fiecare obiectiv."</blockquote>
			<figcaption class="review__who"><strong>Radu P.</strong> Tur privat de o zi</figcaption>
		</figure>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
