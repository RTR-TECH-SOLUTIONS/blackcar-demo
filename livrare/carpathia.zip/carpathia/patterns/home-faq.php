<?php
/**
 * Title: Acasă – întrebări frecvente
 * Slug: carpathia/home-faq
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"cta-band","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull cta-band" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"2rem","left":"4rem"}}}} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"34%"} -->
		<div class="wp-block-column" style="flex-basis:34%">
			<!-- wp:heading -->
			<h2 class="wp-block-heading">Întrebări pe care le primim des</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"muted","style":{"typography":{"fontSize":"0.9375rem"}}} -->
			<p class="has-muted-color has-text-color" style="font-size:0.9375rem">Nu găsiți răspunsul? Scrieți-ne pe WhatsApp, răspundem și noaptea.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="faq">
				<details class="faq__item">
					<summary>Ce se întâmplă dacă zborul întârzie?</summary>
					<p>Urmărim numărul zborului și mutăm ora preluării automat. Așteptarea de 60 de minute se calculează din momentul aterizării reale, nu din ora programată inițial. Nu plătiți nimic în plus.</p>
				</details>
				<details class="faq__item">
					<summary>Unde ne întâlnim în aeroport?</summary>
					<p>În zona de ieșire din terminalul Sosiri, imediat după vamă. Șoferul stă cu o plăcuță pe care scrie numele dumneavoastră. Cu o zi înainte primiți numele lui și numărul de înmatriculare.</p>
				</details>
				<details class="faq__item">
					<summary>Cum se plătește?</summary>
					<p>Cash la șofer, în lei sau euro, sau prin transfer bancar dacă vă trebuie factură. Nu cerem avans pentru transferuri, doar pentru tururile de mai multe zile.</p>
				</details>
				<details class="faq__item">
					<summary>Aveți scaune pentru copii?</summary>
					<p>Da, scaune și înălțătoare, fără cost suplimentar. Spuneți-ne vârsta copilului când rezervați, ca să punem scaunul potrivit.</p>
				</details>
				<details class="faq__item">
					<summary>Puteți emite factură pe firmă?</summary>
					<p>Da. Trimiteți datele firmei la rezervare și primiți factura pe e-mail după cursă. Pentru firme cu curse dese facem o singură factură la sfârșitul lunii.</p>
				</details>
			</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
