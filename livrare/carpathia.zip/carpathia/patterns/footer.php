<?php
/**
 * Title: Subsol
 * Slug: carpathia/footer
 * Categories: carpathia
 * Block Types: core/template-part/footer
 * Inserter: no
 */
$c = carpathia_contact();
?>
<!-- wp:group {"align":"full","className":"site-footer","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}}} -->
<div class="wp-block-group alignfull site-footer" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--30)">

	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"2.5rem","left":"3rem"}}}} -->
	<div class="wp-block-columns alignwide">

		<!-- wp:column {"width":"32%"} -->
		<div class="wp-block-column" style="flex-basis:32%">
			<!-- wp:html -->
			<?php echo carpathia_brand( 'footer' ); ?>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"0.9rem"}},"typography":{"fontSize":"0.9375rem"}}} -->
			<p style="margin-top:0.9rem;font-size:0.9375rem">Transferuri aeroport și tururi private în România.</p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"1.4rem"}},"typography":{"fontSize":"0.875rem"}}} -->
			<p style="margin-top:1.4rem;font-size:0.875rem"><?php echo esc_html( $c['adresa'] ); ?><br><?php echo esc_html( $c['program'] ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Servicii</h3>
			<!-- /wp:heading -->

			<!-- wp:list {"className":"is-style-plain","style":{"spacing":{"blockGap":"0.55rem","padding":{"left":"0"}},"typography":{"fontSize":"0.9375rem"}}} -->
			<ul class="wp-block-list is-style-plain" style="padding-left:0;font-size:0.9375rem">
				<li><a href="/#transferuri">Otopeni - Henri Coandă</a></li>
				<li><a href="/#transferuri">Băneasa - Aurel Vlaicu</a></li>
				<li><a href="/#transferuri">Transfer intercity</a></li>
				<li><a href="/#tururi">Tururi private</a></li>
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Destinații</h3>
			<!-- /wp:heading -->

			<!-- wp:list {"className":"is-style-plain","style":{"spacing":{"blockGap":"0.55rem","padding":{"left":"0"}},"typography":{"fontSize":"0.9375rem"}}} -->
			<ul class="wp-block-list is-style-plain" style="padding-left:0;font-size:0.9375rem">
				<li><a href="/#tururi">Bran și Peleș</a></li>
				<li><a href="/#tururi">Transfăgărășan</a></li>
				<li><a href="/#tururi">Sibiu și Sighișoara</a></li>
				<li><a href="/#tururi">Bucovina</a></li>
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Contact</h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.9375rem"}}} -->
			<p style="font-size:0.9375rem">
				<a href="tel:<?php echo esc_attr( $c['telefon_link'] ); ?>"><?php echo esc_html( $c['telefon'] ); ?></a><br>
				<a href="tel:<?php echo esc_attr( $c['telefon_2_link'] ); ?>"><?php echo esc_html( $c['telefon_2'] ); ?></a><br>
				<a href="mailto:<?php echo esc_attr( $c['email'] ); ?>"><?php echo esc_html( $c['email'] ); ?></a><br>
				<a href="mailto:<?php echo esc_attr( $c['email_2'] ); ?>"><?php echo esc_html( $c['email_2'] ); ?></a><br>
				<a href="<?php echo esc_url( $c['facebook'] ); ?>" target="_blank" rel="noopener">Facebook</a>
			</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->

	<!-- wp:group {"align":"wide","className":"footer-bottom","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"},"style":{"spacing":{"padding":{"top":"1.6rem"},"margin":{"top":"var:preset|spacing|40"},"blockGap":"1rem"}}} -->
	<div class="wp-block-group alignwide footer-bottom" style="margin-top:var(--wp--preset--spacing--40);padding-top:1.6rem">
		<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.8125rem"}}} -->
		<p style="font-size:0.8125rem">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. Site realizat de <a href="https://rtrtech.ro" target="_blank" rel="noopener">RTR Tech Solutions</a>.</p>
		<!-- /wp:paragraph -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.8125rem"}}} -->
		<p style="font-size:0.8125rem">
			<a href="/termeni-si-conditii/">Termeni și condiții</a> ·
			<a href="/politica-de-confidentialitate/">Confidențialitate</a> ·
			<a href="/politica-cookies/">Cookies</a> ·
			<a href="https://anpc.ro/" target="_blank" rel="noopener nofollow">ANPC</a> ·
			<a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener nofollow">SOL</a>
		</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

</div>
<!-- /wp:group -->
