<?php
/**
 * Title: Ghid – lista de articole
 * Slug: carpathia/guide-list
 * Categories: carpathia
 * Inserter: no
 *
 * Interogarea moștenește query-ul principal, ca paginarea și arhivele de
 * categorie să funcționeze fără un al doilea query. Primul articol e scos în
 * evidență prin CSS (`.guide-list > li:first-child`), nu printr-o interogare
 * separată.
 */
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:query {"queryId":30,"query":{"perPage":9,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":true},"align":"wide","className":"guide-query","layout":{"type":"default"}} -->
	<div class="wp-block-query alignwide guide-query">
		<!-- wp:post-template {"className":"guide-list","layout":{"type":"default"}} -->
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","style":{"border":{"radius":"10px"}}} /-->
			<!-- wp:post-terms {"term":"category","className":"guide-cat"} /-->
			<!-- wp:post-title {"level":2,"isLink":true,"className":"guide-title"} /-->
			<!-- wp:post-excerpt {"excerptLength":24,"showMoreOnNewLine":false,"className":"guide-excerpt"} /-->
			<!-- wp:post-date {"format":"j F Y","className":"guide-date"} /-->
			<!-- wp:read-more {"content":"Vezi articolul","className":"guide-more"} /-->
		<!-- /wp:post-template -->

		<!-- wp:query-pagination {"layout":{"type":"flex","justifyContent":"left"},"className":"guide-pagination"} -->
			<!-- wp:query-pagination-previous {"label":"Înapoi"} /-->
			<!-- wp:query-pagination-numbers /-->
			<!-- wp:query-pagination-next {"label":"Mai departe"} /-->
		<!-- /wp:query-pagination -->

		<!-- wp:query-no-results -->
			<!-- wp:paragraph -->
			<p>Încă nu am publicat nimic aici.</p>
			<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
