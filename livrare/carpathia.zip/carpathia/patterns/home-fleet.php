<?php
/**
 * Title: Acasă – flota
 * Slug: carpathia/home-fleet
 * Categories: carpathia
 * Inserter: no
 */
$u = get_stylesheet_directory_uri() . '/assets/images/';
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"align":"wide","verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"2.5rem","left":"4rem"}}}} -->
	<div class="wp-block-columns alignwide are-vertically-aligned-center">

		<!-- wp:column {"verticalAlignment":"center","width":"46%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:46%">
			<!-- wp:html -->
			<img src="<?php echo esc_url( $u . 'flota.jpg' ); ?>" width="1400" height="875" loading="lazy" decoding="async" alt="Mercedes-Benz V-Class al Blackcar, în parcarea Aeroportului Otopeni" style="width:100%;height:auto;border-radius:12px;display:block">
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center"} -->
		<div class="wp-block-column is-vertically-aligned-center">
			<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"0.7rem"}}}} -->
			<h2 class="wp-block-heading" style="margin-bottom:0.7rem">Mașinile</h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"1.8rem"}}},"textColor":"muted"} -->
			<p class="has-muted-color has-text-color" style="margin-bottom:1.8rem">Toate sunt ale noastre, verificate în service la fiecare 10.000 de kilometri. Spunem din start ce mașină vine, nu „un autoturism".</p>
			<!-- /wp:paragraph -->

			<!-- wp:html -->
			<div class="fleet-specs">
				<div class="fleet__item" style="background:transparent;border:0;padding:0;margin-bottom:1.6rem">
					<p class="fleet__name">Business</p>
					<p class="fleet__models">Mercedes-Benz E-Class</p>
					<ul class="fleet__specs">
						<li><span>Pasageri</span><span>până la 3</span></li>
						<li><span>Bagaje mari</span><span>3</span></li>
					</ul>
				</div>
				<div class="fleet__item" style="background:transparent;border:0;padding:0;margin-bottom:1.6rem">
					<p class="fleet__name">Van</p>
					<p class="fleet__models">Mercedes-Benz V-Class</p>
					<ul class="fleet__specs">
						<li><span>Pasageri</span><span>până la 7</span></li>
						<li><span>Bagaje mari</span><span>7</span></li>
					</ul>
				</div>
				<div class="fleet__item" style="background:transparent;border:0;padding:0">
					<p class="fleet__name">Grup</p>
					<p class="fleet__models">Volkswagen Multivan sau Transporter</p>
					<ul class="fleet__specs">
						<li><span>Pasageri</span><span>până la 8</span></li>
						<li><span>Bagaje mari</span><span>8</span></li>
					</ul>
				</div>
			</div>
			<!-- /wp:html -->
		</div>
		<!-- /wp:column -->

	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
