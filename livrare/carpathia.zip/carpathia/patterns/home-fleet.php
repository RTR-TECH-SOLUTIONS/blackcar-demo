<?php
/**
 * Title: Acasă – mașinile
 * Slug: carpathia/home-fleet
 * Categories: carpathia
 * Inserter: no
 */
$u = get_stylesheet_directory_uri() . '/assets/images/';
?>
<!-- wp:group {"align":"full","anchor":"masini","className":"section-dark fleet-section","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull section-dark fleet-section" id="masini" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Mașinile</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Astea sunt mașinile mele, fotografiate așa cum arată. Nu lucrez cu subcontractori și vă spun din start ce model vine.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<ul class="fleet-gallery alignwide">
		<li class="fleet-shot fleet-shot--wide">
			<img src="<?php echo esc_url( $u . 'auto-vclass-terminal.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Mercedes-Benz V-Class în fața terminalului de la Otopeni">
			<p class="fleet-shot__caption"><strong>Mercedes-Benz V-Class</strong> la Otopeni, înainte de o preluare</p>
		</li>
		<li class="fleet-shot">
			<img src="<?php echo esc_url( $u . 'auto-eclass-fata.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Mercedes-Benz E-Class văzut din față">
			<p class="fleet-shot__caption"><strong>Mercedes-Benz E-Class</strong>, clasa business</p>
		</li>
		<li class="fleet-shot">
			<img src="<?php echo esc_url( $u . 'auto-eclass-spate.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Mercedes-Benz E-Class văzut din spate">
			<p class="fleet-shot__caption">Portbagaj de sedan, pentru bagaj obișnuit</p>
		</li>
		<li class="fleet-shot">
			<img src="<?php echo esc_url( $u . 'masina-otopeni.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Vanul în parcarea aeroportului, cu un avion pe pistă în spate">
			<p class="fleet-shot__caption">Vanul, în parcarea de la sosiri</p>
		</li>
		<li class="fleet-shot">
			<img src="<?php echo esc_url( $u . 'auto-interior.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Bancheta din spate a vanului, tapițerie din piele">
			<p class="fleet-shot__caption">Bancheta din spate, cu scaune individuale</p>
		</li>
		<li class="fleet-shot">
			<img src="<?php echo esc_url( $u . 'auto-bagaje.jpg' ); ?>" width="1200" height="900" loading="lazy" decoding="async" alt="Spațiul de bagaje al vanului, cu banchetele rabatate">
			<p class="fleet-shot__caption">Spațiul de bagaje, cu banchetele rabatate</p>
		</li>
	</ul>
	<!-- /wp:html -->

	<!-- wp:html -->
	<div class="fleet-classes alignwide">
		<div class="fleet-class">
			<p class="fleet-class__name">Business</p>
			<p class="fleet-class__model">Mercedes-Benz E-Class</p>
			<ul class="fleet__specs">
				<li><span>Pasageri</span><span>până la 3</span></li>
				<li><span>Bagaje mari</span><span>3</span></li>
			</ul>
		</div>
		<div class="fleet-class">
			<p class="fleet-class__name">Van</p>
			<p class="fleet-class__model">Mercedes-Benz V-Class</p>
			<ul class="fleet__specs">
				<li><span>Pasageri</span><span>până la 7</span></li>
				<li><span>Bagaje mari</span><span>în limita spațiului din portbagajul vanului</span></li>
			</ul>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
