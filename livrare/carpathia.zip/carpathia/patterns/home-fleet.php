<?php
/**
 * Title: Acasă – mașinile
 * Slug: carpathia/home-fleet
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","anchor":"masini","className":"section-dark fleet-section","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull section-dark fleet-section" id="masini" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Mașinile</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<ul class="fleet-gallery alignwide">
		<li class="fleet-shot fleet-shot--wide">
			<?php echo carpathia_theme_img( 'auto-vclass-terminal', array( 480, 800, 1200 ), array( 1200, 900 ), 'Mercedes-Benz V-Class în fața terminalului de la Otopeni', '(min-width: 1280px) 810px, (min-width: 1000px) 64vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot">
			<?php echo carpathia_theme_img( 'auto-eclass-fata', array( 480, 800, 1200 ), array( 1200, 900 ), 'Mercedes-Benz E-Class văzut din față', '(min-width: 1280px) 390px, (min-width: 1000px) 31vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot">
			<?php echo carpathia_theme_img( 'auto-eclass-spate', array( 480, 800, 1200 ), array( 1200, 900 ), 'Mercedes-Benz E-Class văzut din spate', '(min-width: 1280px) 390px, (min-width: 1000px) 31vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot">
			<?php echo carpathia_theme_img( 'masina-otopeni', array( 480, 800 ), array( 1200, 900 ), 'Vanul în parcarea aeroportului, cu un avion pe pistă în spate', '(min-width: 1280px) 390px, (min-width: 1000px) 31vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot">
			<?php echo carpathia_theme_img( 'auto-interior', array( 480, 800, 1200 ), array( 1200, 900 ), 'Bancheta din spate a vanului, tapițerie din piele', '(min-width: 1280px) 390px, (min-width: 1000px) 31vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot">
			<?php echo carpathia_theme_img( 'auto-bagaje', array( 480, 800, 1200 ), array( 1200, 900 ), 'Spațiul de bagaje al vanului, cu banchetele rabatate', '(min-width: 1280px) 390px, (min-width: 1000px) 31vw, (min-width: 640px) 48vw, calc(100vw - 2.5rem)' ); ?>
		</li>
		<li class="fleet-shot fleet-shot--banner">
			<?php echo carpathia_theme_img( 'van-negru', array( 640, 1000, 1400, 2000 ), array( 2000, 1096 ), 'Van Mercedes-Benz V-Class negru, parcat', '(min-width: 1280px) 1220px, calc(100vw - 2.5rem)' ); ?>
		</li>
	</ul>
	<!-- /wp:html -->

	<!-- wp:html -->
	<div class="fleet-classes alignwide">
		<div class="fleet-class">
			<p class="fleet-class__name">Business</p>
			<p class="fleet-class__model">Mercedes-Benz E-Class</p>
			<ul class="fleet__specs">
				<li><span>Pasageri</span><span>până la 3</span></li>
				<li><span>Bagaje mari</span><span>3</span></li>
			</ul>
		</div>
		<div class="fleet-class">
			<p class="fleet-class__name">Vanuri</p>
			<p class="fleet-class__model">Mercedes-Benz V-Class</p>
			<ul class="fleet__specs">
				<li><span>Pasageri</span><span>până la 6/7</span></li>
				<li><span>Bagaje mari</span><span>în limita spațiului din portbagajul vanului</span></li>
			</ul>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
