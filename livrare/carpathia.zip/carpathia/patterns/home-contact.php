<?php
/**
 * Title: Acasă – contact
 * Slug: carpathia/home-contact
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","anchor":"contact","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" id="contact" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Contact</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Cel mai repede răspundem pe WhatsApp. Scrieți-ne ruta și data, iar dacă veniți cu avionul, și numărul zborului.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="contact-grid alignwide">
		<div class="contact-item">
			<p class="contact-item__label">Telefon</p>
			<p class="contact-item__value"><a href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon' ) ); ?></a></p>
			<p class="contact-item__note">Răspundem și la mesaje, dacă suntem pe drum.</p>
		</div>
		<div class="contact-item">
			<p class="contact-item__label">WhatsApp</p>
			<p class="contact-item__value"><a href="<?php echo esc_url( carpathia_contact( 'whatsapp_link' ) ); ?>" target="_blank" rel="noopener">Scrieți-ne</a></p>
			<p class="contact-item__note">Confirmarea și prețul vă rămân scrise în conversație.</p>
		</div>
		<div class="contact-item">
			<p class="contact-item__label">E-mail</p>
			<p class="contact-item__value"><a href="mailto:<?php echo esc_attr( carpathia_contact( 'email' ) ); ?>"><?php echo esc_html( carpathia_contact( 'email' ) ); ?></a></p>
			<p class="contact-item__note">Pentru facturi și rezervări făcute din timp.</p>
		</div>
		<div class="contact-item">
			<p class="contact-item__label">Program</p>
			<p class="contact-item__value"><?php echo esc_html( carpathia_contact( 'program' ) ); ?></p>
			<p class="contact-item__note">Pentru curse în afara programului, anunțați-ne cu o zi înainte.</p>
		</div>
	</div>
	<!-- /wp:html -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"left"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#cerere">Cere prețul pentru cursa ta</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
