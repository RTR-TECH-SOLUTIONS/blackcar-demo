<?php
/**
 * Title: Acasă – contact
 * Slug: carpathia/home-contact
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","anchor":"contact","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignfull" id="contact" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--30)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Contact</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="contact-grid contact-grid--2 alignwide">
		<div class="contact-item">
			<p class="contact-item__label">Telefon</p>
			<p class="contact-item__value"><a href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon' ) ); ?></a></p>
			<p class="contact-item__value"><a href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_2_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon_2' ) ); ?></a></p>
			<p class="contact-item__note">Răspundem și la mesaje, dacă suntem pe drum.</p>
		</div>
		<div class="contact-item">
			<p class="contact-item__label">E-mail</p>
			<p class="contact-item__value"><a href="mailto:<?php echo esc_attr( carpathia_contact( 'email' ) ); ?>"><?php echo esc_html( carpathia_contact( 'email' ) ); ?></a></p>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
