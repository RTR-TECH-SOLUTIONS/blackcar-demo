<?php
/**
 * Title: Acasă – chemare finală
 * Slug: carpathia/home-cta
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"section-dark","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignfull section-dark" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"0.8rem"}}}} -->
		<h2 class="wp-block-heading">Spuneți-ne ruta și primiți prețul</h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}},"typography":{"fontSize":"1.0625rem"}}} -->
		<p style="margin-bottom:var(--wp--preset--spacing--30);font-size:1.0625rem">Răspundem non-stop, inclusiv pentru curse de noapte și rezervări făcute în aceeași zi.</p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"left"}} -->
		<div class="wp-block-buttons">
			<!-- wp:button {"className":"is-style-gold"} -->
			<div class="wp-block-button is-style-gold"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( carpathia_whatsapp_link() ); ?>" target="_blank" rel="noopener">Scrie pe WhatsApp</a></div>
			<!-- /wp:button -->
			<!-- wp:button {"className":"is-style-outline-light"} -->
			<div class="wp-block-button is-style-outline-light"><a class="wp-block-button__link wp-element-button" href="tel:<?php echo esc_attr( carpathia_contact( 'telefon_link' ) ); ?>"><?php echo esc_html( carpathia_contact( 'telefon' ) ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
