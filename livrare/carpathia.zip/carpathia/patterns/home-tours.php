<?php
/**
 * Title: Acasă – tururi
 * Slug: carpathia/home-tours
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"cta-band","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull cta-band" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Tururi private</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Plecăm dimineața de la hotelul dumneavoastră și vă aducem înapoi seara. Fără alți turiști în mașină, cu opriri oriunde cereți pe drum.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:query {"queryId":10,"query":{"perPage":3,"pages":0,"offset":0,"postType":"tur","order":"asc","orderBy":"menu_order","inherit":false},"align":"wide","className":"tours-query","layout":{"type":"default"}} -->
	<div class="wp-block-query alignwide tours-query">
		<!-- wp:post-template {"className":"tours-grid","layout":{"type":"grid","columnCount":3}} -->
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3","style":{"border":{"radius":"10px"}}} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"top":"1rem","bottom":"0.4rem"}},"typography":{"fontSize":"1.3rem"}}} /-->
			<!-- wp:post-excerpt {"excerptLength":24,"showMoreOnNewLine":false,"style":{"typography":{"fontSize":"0.9375rem"}},"textColor":"muted"} /-->
			<!-- wp:post-terms {"term":"post_tag","separator":"  ·  ","style":{"typography":{"fontSize":"0.8125rem"}},"textColor":"muted"} /-->
		<!-- /wp:post-template -->
	</div>
	<!-- /wp:query -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"left"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:button {"className":"is-style-outline"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/tururi/">Vezi toate tururile</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
