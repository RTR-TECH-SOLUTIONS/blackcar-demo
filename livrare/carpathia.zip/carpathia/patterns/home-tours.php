<?php
/**
 * Title: Acasă – tururi
 * Slug: carpathia/home-tours
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","anchor":"tururi","className":"cta-band","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull cta-band" id="tururi" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Tururi private</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Pe trasee recomandate de noi sau oriunde doriți dumneavoastră.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:query {"queryId":10,"query":{"perPage":9,"pages":0,"offset":0,"postType":"tur","order":"asc","orderBy":"menu_order","inherit":false},"align":"wide","className":"tours-query","layout":{"type":"default"}} -->
	<div class="wp-block-query alignwide tours-query">
		<!-- wp:post-template {"className":"tours-grid","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"13rem"}} -->
			<!-- wp:post-featured-image {"isLink":true,"sizeSlug":"medium_large","aspectRatio":"4/3","style":{"border":{"radius":"10px"}}} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"top":"0.85rem","bottom":"0.3rem"}},"typography":{"fontSize":"1.0625rem"}}} /-->
			<!-- wp:post-excerpt {"excerptLength":14,"showMoreOnNewLine":false,"style":{"typography":{"fontSize":"0.875rem"}},"textColor":"muted"} /-->
		<!-- /wp:post-template -->
	</div>
	<!-- /wp:query -->

</div>
<!-- /wp:group -->
