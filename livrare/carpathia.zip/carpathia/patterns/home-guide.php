<?php
/**
 * Title: Acasă – ghid de destinații
 * Slug: carpathia/home-guide
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Ghid de destinații</h2>
		<!-- /wp:heading -->
		<!-- wp:paragraph -->
		<p>Locurile în care mergem des, scrise de șoferii care le străbat săptămânal: cât se face până acolo, când e aglomerat și ce merită văzut în drum.</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:query {"queryId":20,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"align":"wide","layout":{"type":"default"}} -->
	<div class="wp-block-query alignwide">
		<!-- wp:post-template {"className":"guide-grid","layout":{"type":"default"}} -->
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","style":{"border":{"radius":"10px"}}} /-->
			<!-- wp:post-terms {"term":"category","className":"guide-cat"} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"className":"guide-title"} /-->
			<!-- wp:post-excerpt {"excerptLength":24,"showMoreOnNewLine":false,"className":"guide-excerpt"} /-->
		<!-- /wp:post-template -->
	</div>
	<!-- /wp:query -->

	<!-- wp:buttons {"align":"wide","layout":{"type":"flex","justifyContent":"left"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons alignwide" style="margin-top:var(--wp--preset--spacing--40)">
		<!-- wp:button {"className":"is-style-outline"} -->
		<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/ghid/">Toate destinațiile</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
