<?php
/**
 * Title: Acasă – cum funcționează
 * Slug: carpathia/home-steps
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Cum se face o rezervare</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="steps alignwide">
		<div class="step">
			<h3>Trimiteți ruta</h3>
			<p>Pe WhatsApp sau din formular: de unde, până unde, data și numărul zborului dacă veniți cu avionul.</p>
		</div>
		<div class="step">
			<h3>Primiți prețul fix</h3>
			<p>Vă răspundem cu suma exactă și cu tipul mașinii. Dacă acceptați, rezervarea e confirmată pe loc.</p>
		</div>
		<div class="step">
			<h3>Vă așteptăm la ieșire</h3>
			<p>Cu o zi înainte trimitem numele șoferului și numărul de înmatriculare. La sosiri stăm în zona de ieșire, cu plăcuța cu numele dumneavoastră.</p>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
