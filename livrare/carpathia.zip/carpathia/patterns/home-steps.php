<?php
/**
 * Title: Acasă – cum funcționează
 * Slug: carpathia/home-steps
 * Categories: carpathia
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">

	<!-- wp:group {"align":"wide","className":"section-head","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-group alignwide section-head" style="margin-bottom:var(--wp--preset--spacing--40)">
		<!-- wp:heading -->
		<h2 class="wp-block-heading">Pentru rezervare</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:html -->
	<div class="steps alignwide">
		<div class="step">
			<h3>Ne trimiteți ruta</h3>
			<p>Locul de preluare, destinația și numărul zborului (dacă preluarea este de la aeroport).</p>
		</div>
		<div class="step">
			<h3>Prețul, stabilit de comun acord</h3>
			<p>Prețul este cel stabilit de comun acord pentru ruta aleasă și rămâne același.</p>
		</div>
		<div class="step">
			<h3>Șoferul vă așteaptă la ieșire</h3>
			<p>Cu numele dumneavoastră la vedere, timp de 60 de minute de la ora stabilită, orice depășire fiind taxată suplimentar. Sau puteți stabili după cât timp de la aterizare să sosească șoferul.</p>
		</div>
	</div>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
