<?php
/**
 * Title: Antet
 * Slug: carpathia/header
 * Categories: carpathia
 * Block Types: core/template-part/header
 * Inserter: no
 */
$tel     = carpathia_contact( 'telefon' );
$tel_url = 'tel:' . carpathia_contact( 'telefon_link' );
$email   = carpathia_contact( 'email' );
$program = carpathia_contact( 'program' );
?>
<!-- wp:group {"className":"site-topbar","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"0.55rem","bottom":"0.55rem"}}}} -->
<div class="wp-block-group site-topbar" style="padding-top:0.55rem;padding-bottom:0.55rem">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.8125rem"}}} -->
		<p style="font-size:0.8125rem"><?php echo esc_html( $program ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"1.5rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:paragraph {"className":"topbar-email","style":{"typography":{"fontSize":"0.8125rem"}}} -->
			<p class="topbar-email" style="font-size:0.8125rem"><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"0.8125rem","fontWeight":"600"}}} -->
			<p style="font-size:0.8125rem;font-weight:600"><a href="<?php echo esc_attr( $tel_url ); ?>"><?php echo esc_html( $tel ); ?></a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"site-header","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"0.9rem","bottom":"0.9rem"}}}} -->
<div class="wp-block-group site-header" style="padding-top:0.9rem;padding-bottom:0.9rem">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","justifyContent":"space-between","flexWrap":"nowrap"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:html -->
		<?php echo carpathia_brand(); ?>
		<!-- /wp:html -->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"},"style":{"spacing":{"blockGap":"1.75rem"}}} -->
		<div class="wp-block-group">
			<!-- wp:navigation {"textColor":"base","overlayMenu":"mobile","overlayBackgroundColor":"ink","overlayTextColor":"base","layout":{"type":"flex","justifyContent":"right","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"1.6rem"}}} -->
				<!-- wp:navigation-link {"label":"Transferuri","url":"/transfer-aeroport/","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:navigation-link {"label":"Tururi","url":"/tururi/","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:navigation-link {"label":"Flota","url":"/flota/","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:navigation-link {"label":"Firme","url":"/firme/","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:navigation-link {"label":"Ghid de destinații","url":"/ghid/","kind":"custom","isTopLevelLink":true} /-->
				<!-- wp:navigation-link {"label":"Contact","url":"/contact/","kind":"custom","isTopLevelLink":true} /-->
			<!-- /wp:navigation -->

			<!-- wp:buttons {"className":"header-cta","layout":{"type":"flex"}} -->
			<div class="wp-block-buttons header-cta">
				<!-- wp:button -->
				<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#cerere">Cere ofertă</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
