<?php
/**
 * SEO fără plugin: titlul și descrierea din Google, imaginea pentru distribuire
 * pe Facebook și WhatsApp și datele structurate (firma, tururile, articolele).
 *
 * Titlul și descrierea se scriu pentru fiecare pagină, tur sau articol din
 * panoul „Google (SEO)" din bara laterală a editorului. Dacă rămân goale, se
 * folosesc titlul și rezumatul.
 *
 * @package TransferOtopeni
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tipurile de conținut cu câmpuri SEO proprii.
 */
function carpathia_seo_post_types() {
	return array( 'page', 'post', 'tur' );
}

/**
 * Câmpurile „Titlu în Google" și „Descriere în Google", salvate ca meta.
 */
function carpathia_seo_register_meta() {
	foreach ( carpathia_seo_post_types() as $type ) {
		foreach ( array( 'carpathia_seo_titlu', 'carpathia_seo_descriere' ) as $key ) {
			register_post_meta(
				$type,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'carpathia_seo_register_meta' );

/**
 * Panoul din editor, doar pe ecranele de editare pentru pagini, tururi și articole.
 */
function carpathia_seo_editor_panel() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( ! $screen || 'post' !== $screen->base || ! in_array( $screen->post_type, carpathia_seo_post_types(), true ) ) {
		return;
	}

	$file = '/assets/js/seo-panel.js';

	wp_enqueue_script(
		'carpathia-seo-panel',
		get_stylesheet_directory_uri() . $file,
		array( 'wp-plugins', 'wp-editor', 'wp-components', 'wp-data', 'wp-element' ),
		(string) filemtime( get_stylesheet_directory() . $file ),
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'carpathia_seo_editor_panel' );

/**
 * Pagina din care se iau câmpurile SEO pentru adresa curentă: prima pagină și
 * blogul sunt pagini obișnuite în panou, deci au și ele câmpurile lor.
 */
function carpathia_seo_object_id() {
	if ( is_front_page() && get_option( 'page_on_front' ) ) {
		return (int) get_option( 'page_on_front' );
	}

	if ( is_home() && get_option( 'page_for_posts' ) ) {
		return (int) get_option( 'page_for_posts' );
	}

	if ( is_singular( carpathia_seo_post_types() ) ) {
		return (int) get_queried_object_id();
	}

	return 0;
}

/**
 * Lista tuturor tururilor nu e o pagină în panou, deci textele ei stau aici.
 */
function carpathia_seo_tours_archive() {
	return array(
		'titlu'     => 'Tururi private și excursii din București | Transfer Otopeni.ro',
		'descriere' => 'Excursii de o zi din București cu șofer privat: Castelul Peleș, Bran și Cantacuzino, Sinaia, Bușteni, Brașov, Sighișoara și Salina Slănic Prahova.',
	);
}

/**
 * Titlul din Google. Titlul mare din pagină rămâne neschimbat.
 */
function carpathia_seo_document_title( $title ) {
	if ( is_post_type_archive( 'tur' ) ) {
		return esc_html( carpathia_seo_tours_archive()['titlu'] );
	}

	$id = carpathia_seo_object_id();

	if ( $id ) {
		$custom = trim( (string) get_post_meta( $id, 'carpathia_seo_titlu', true ) );

		if ( '' !== $custom ) {
			return esc_html( $custom );
		}
	}

	return $title;
}
add_filter( 'pre_get_document_title', 'carpathia_seo_document_title' );

function carpathia_seo_title_separator() {
	return '|';
}
add_filter( 'document_title_separator', 'carpathia_seo_title_separator' );

/**
 * Descrierea din Google: câmpul SEO, apoi rezumatul, apoi începutul textului.
 */
function carpathia_seo_description() {
	if ( is_post_type_archive( 'tur' ) ) {
		return carpathia_seo_tours_archive()['descriere'];
	}

	$id   = carpathia_seo_object_id();
	$text = '';

	if ( $id ) {
		$text = (string) get_post_meta( $id, 'carpathia_seo_descriere', true );

		if ( '' === trim( $text ) && has_excerpt( $id ) ) {
			$text = get_post_field( 'post_excerpt', $id );
		}

		if ( '' === trim( $text ) ) {
			$content = excerpt_remove_blocks( (string) get_post_field( 'post_content', $id ) );
			$text    = wp_trim_words( wp_strip_all_tags( strip_shortcodes( $content ) ), 26, '…' );
		}
	} elseif ( is_category() ) {
		$text = wp_strip_all_tags( category_description() );
	}

	if ( '' === trim( $text ) ) {
		$text = get_bloginfo( 'description' );
	}

	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * Adresa canonică. WordPress o pune singur pe pagini, tururi și articole;
 * listele (tururi, blog, categorii) o primesc de aici.
 */
function carpathia_seo_canonical() {
	if ( is_singular() ) {
		return (string) wp_get_canonical_url();
	}

	if ( is_post_type_archive( 'tur' ) ) {
		return (string) get_post_type_archive_link( 'tur' );
	}

	if ( is_home() ) {
		$paged = max( 1, (int) get_query_var( 'paged' ) );
		return $paged > 1 ? get_pagenum_link( $paged ) : (string) get_permalink( get_option( 'page_for_posts' ) );
	}

	if ( is_category() ) {
		return (string) get_category_link( get_queried_object_id() );
	}

	return '';
}

/**
 * Imaginea care apare când linkul e trimis pe Facebook sau WhatsApp: poza
 * turului sau a articolului, altfel imaginea generală a site-ului.
 */
function carpathia_seo_image() {
	$fallback = array(
		'url'    => get_stylesheet_directory_uri() . '/assets/images/og-transfer-otopeni.jpg',
		'width'  => 1200,
		'height' => 630,
		'alt'    => 'Van Mercedes-Benz V-Class în fața unui terminal de aeroport, seara',
	);

	$id = carpathia_seo_object_id();

	if ( ! $id || is_front_page() || ! has_post_thumbnail( $id ) ) {
		return $fallback;
	}

	$thumb = get_post_thumbnail_id( $id );
	$src   = wp_get_attachment_image_src( $thumb, 'large' );

	if ( ! $src ) {
		return $fallback;
	}

	return array(
		'url'    => $src[0],
		'width'  => (int) $src[1],
		'height' => (int) $src[2],
		'alt'    => (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ),
	);
}

/**
 * Descrierea, adresa canonică a listelor, etichetele pentru distribuire și
 * datele structurate, toate în <head>.
 */
function carpathia_seo_head() {
	$desc  = carpathia_seo_description();
	$url   = carpathia_seo_canonical();
	$image = carpathia_seo_image();

	if ( '' !== $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
	}

	if ( '' !== $url && ! is_singular() ) {
		printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
	}

	$tags = array(
		'og:locale'       => 'ro_RO',
		'og:type'         => is_singular( 'post' ) ? 'article' : 'website',
		'og:site_name'    => get_bloginfo( 'name' ),
		'og:title'        => wp_get_document_title(),
		'og:description'  => $desc,
		'og:url'          => $url,
		'og:image'        => $image['url'],
		'og:image:width'  => $image['width'],
		'og:image:height' => $image['height'],
		'og:image:alt'    => $image['alt'],
	);

	foreach ( $tags as $property => $content ) {
		if ( '' === (string) $content ) {
			continue;
		}

		$value = in_array( $property, array( 'og:url', 'og:image' ), true ) ? esc_url( $content ) : esc_attr( $content );
		printf( '<meta property="%s" content="%s">' . "\n", esc_attr( $property ), $value );
	}

	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

	carpathia_seo_schema( $desc, $image );
}
add_action( 'wp_head', 'carpathia_seo_head', 5 );

/**
 * Firul de navigare pentru Google: Acasă › secțiune › pagină.
 */
function carpathia_seo_breadcrumbs( $items ) {
	$list = array();

	foreach ( array_values( $items ) as $i => $item ) {
		$list[] = array(
			'@type'    => 'ListItem',
			'position' => $i + 1,
			'name'     => $item[0],
			'item'     => $item[1],
		);
	}

	return array(
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $list,
	);
}

/**
 * Datele structurate: site-ul și firma pe toate paginile, plus turul sau
 * articolul pe paginile lor.
 */
function carpathia_seo_schema( $desc, $image ) {
	$c     = carpathia_contact();
	$home  = home_url( '/' );
	$firma = $home . '#firma';

	$servicii = array(
		'Transfer aeroport Otopeni – Henri Coandă',
		'Transfer aeroport Băneasa – Aurel Vlaicu',
		'Transfer intercity',
		'Tururi private din București',
	);

	$graph = array(
		array(
			'@type'      => 'WebSite',
			'@id'        => $home . '#site',
			'url'        => $home,
			'name'       => get_bloginfo( 'name' ),
			'inLanguage' => 'ro-RO',
			'publisher'  => array( '@id' => $firma ),
		),
		array(
			'@type'                     => 'LocalBusiness',
			'@id'                       => $firma,
			'name'                      => get_bloginfo( 'name' ),
			'url'                       => $home,
			'logo'                      => get_stylesheet_directory_uri() . '/assets/images/logo-transfer-otopeni.png',
			'image'                     => get_stylesheet_directory_uri() . '/assets/images/og-transfer-otopeni.jpg',
			'description'               => 'Transferuri de la și către aeroporturile Otopeni și Băneasa, oriunde doriți, și tururi private din București.',
			'telephone'                 => $c['telefon_link'],
			'email'                     => $c['email'],
			'contactPoint'              => array(
				array(
					'@type'       => 'ContactPoint',
					'telephone'   => $c['telefon_link'],
					'email'       => $c['email'],
					'contactType' => 'customer service',
				),
				array(
					'@type'       => 'ContactPoint',
					'telephone'   => $c['telefon_2_link'],
					'email'       => $c['email_2'],
					'contactType' => 'reservations',
				),
			),
			'address'                   => array(
				'@type'           => 'PostalAddress',
				'addressLocality' => 'București',
				'addressCountry'  => 'RO',
			),
			'areaServed'                => array(
				array(
					'@type' => 'City',
					'name'  => 'București',
				),
				array(
					'@type' => 'Country',
					'name'  => 'România',
				),
			),
			'openingHoursSpecification' => array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ),
				'opens'     => '00:00',
				'closes'    => '23:59',
			),
			'sameAs'                    => array( $c['facebook'] ),
			'hasOfferCatalog'           => array(
				'@type'           => 'OfferCatalog',
				'name'            => 'Servicii',
				'itemListElement' => array_map(
					function ( $name ) {
						return array(
							'@type'       => 'Offer',
							'itemOffered' => array(
								'@type' => 'Service',
								'name'  => $name,
							),
						);
					},
					$servicii
				),
			),
		),
	);

	if ( is_singular( 'tur' ) ) {
		$id  = get_queried_object_id();
		$url = get_permalink( $id );

		$graph[] = array(
			'@type'       => 'TouristTrip',
			'@id'         => $url . '#tur',
			'name'        => get_post_field( 'post_title', $id ),
			'description' => $desc,
			'url'         => $url,
			'image'       => $image['url'],
			'provider'    => array( '@id' => $firma ),
		);
		$graph[] = carpathia_seo_breadcrumbs(
			array(
				array( 'Acasă', $home ),
				array( 'Tururi', get_post_type_archive_link( 'tur' ) ),
				array( get_post_field( 'post_title', $id ), $url ),
			)
		);
	}

	if ( is_singular( 'post' ) ) {
		$id   = get_queried_object_id();
		$url  = get_permalink( $id );
		$blog = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : $home;

		$graph[] = array(
			'@type'            => 'BlogPosting',
			'@id'              => $url . '#articol',
			'headline'         => get_post_field( 'post_title', $id ),
			'description'      => $desc,
			'image'            => $image['url'],
			'datePublished'    => get_the_date( 'c', $id ),
			'dateModified'     => get_the_modified_date( 'c', $id ),
			'author'           => array( '@id' => $firma ),
			'publisher'        => array( '@id' => $firma ),
			'mainEntityOfPage' => $url,
			'inLanguage'       => 'ro-RO',
		);
		$graph[] = carpathia_seo_breadcrumbs(
			array(
				array( 'Acasă', $home ),
				array( 'Blog', $blog ),
				array( get_post_field( 'post_title', $id ), $url ),
			)
		);
	}

	printf(
		'<script type="application/ld+json">%s</script>' . "\n",
		wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG
		)
	);
}
